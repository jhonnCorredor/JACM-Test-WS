package com.session3.JACM_test_WS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JacmTestWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
